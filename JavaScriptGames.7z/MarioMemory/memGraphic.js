document.getElementById("gameTitle").innerHTML = "Pokemem";
document.getElementById("gameDes").innerHTML = "Trova le coppie di immagini nel minor tempo possibile";
// Creazione di container
var divContainer = document.createElement("div");
divContainer.id = "container";

// Stile di container
divContainer.style.position = "relative";
divContainer.style.top = "55%";
divContainer.style.left = "50%";
divContainer.style.marginLeft = "-248px";
divContainer.style.width = "500px";
divContainer.style.height = "530px";
divContainer.style.borderStyle = "solid";
divContainer.style.borderWidth = "2px";
divContainer.style.backgroundColor = "#33ffff";
divContainer.style.zIndex = 10;

// Appending container dentro body
document.getElementsByTagName("body")[0].appendChild(divContainer);

//Creazione di divTime
var divTime;
container.appendChild(divTime = document.createElement("div"));
divTime.id = "time";
divTime.style.position = "absolute";
divTime.style.top = "0px";
divTime.style.left = "47%";
divTime.style.zIndex = 15;


//Creazione di timeLabel
var timeLabel = document.createElement('Label');
time.appendChild(timeLabel);
timeLabel.id = "record";
timeLabel.style.left = "250px";
timeLabel.style.fontFamily = "Verdana, Helvetica, sans-serif";
timeLabel.innerHTML = "0:00";


//Creazione di game
var divGame;
container.appendChild(divGame = document.createElement("div"));
divGame.id = "game";

// Stile di game

divGame.style.position = "absolute";
divGame.style.top = "30px";
divGame.style.width = "500px";
divGame.style.height = "500px";
divGame.style.borderStyle = "solid";
divGame.style.borderWidth = "1px";
divGame.style.zIndex = 20;
divGame.style.backgroundColor = "red";


var x = 0;
var y = 0;
var divCard = new Array();

for (var i = 0; i < 16; i++) { 
	x = i % 4;
    game.appendChild(divCard[i] = document.createElement("div"));
	divCard[i].id = "card" + i;
	divCard[i].style.position = "absolute";
	divCard[i].style.backgroundImage = "url('Giochi/MarioMemory/retro.png')";
	divCard[i].style.width = "125px";
	divCard[i].style.height = "125px";
	if (i % 4 == 0 && i!=0) y ++;
	divCard[i].style.left = x * 125 + "px";
	divCard[i].style.top = y * 125 + "px";
	divCard[i].style.zIndex = 30;
	
}

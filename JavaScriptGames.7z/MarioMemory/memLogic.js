
var backGround = ["1", "1", 
					"2", "2", 
					"3", "3", 
					"4", "4", 
					"5", "5", 
					"6", "6", 
					"7", "7",
					"8", "8"];

backGround.sort(function(a, b){return 0.5 - Math.random()});

window.onload = function (){
	var stClick = 0;
	var sdClick = 0;
	var stId = 0;
	var sdId = 0;
	var flag = 0;
	var realSec = 0;
	var sec = 0;
	var min = 0;
	var toClear = setInterval(function(){ timer() }, 1000);

	function timer() {
		realSec++;
		if (realSec < 10){
			sec = "0" + realSec;
		}
		else {
			sec = realSec;
		}
		if (realSec == 60){
			min++;
			realSec = 0;
			sec = "00";
		}
		document.getElementById("record").innerHTML = min + ":" + sec;
	}

	
	document.getElementById("card"+0).onclick = function () {checkCard(0);}
	document.getElementById("card"+1).onclick = function () {checkCard(1);}
	document.getElementById("card"+2).onclick = function () {checkCard(2);}
	document.getElementById("card"+3).onclick = function () {checkCard(3);}
	document.getElementById("card"+4).onclick = function () {checkCard(4);}
	document.getElementById("card"+5).onclick = function () {checkCard(5);}
	document.getElementById("card"+6).onclick = function () {checkCard(6);}
	document.getElementById("card"+7).onclick = function () {checkCard(7);}
	document.getElementById("card"+8).onclick = function () {checkCard(8);}
	document.getElementById("card"+9).onclick = function () {checkCard(9);}
	document.getElementById("card"+10).onclick = function () {checkCard(10);}
	document.getElementById("card"+11).onclick = function () {checkCard(11);}
	document.getElementById("card"+12).onclick = function () {checkCard(12);}
	document.getElementById("card"+13).onclick = function () {checkCard(13);}
	document.getElementById("card"+14).onclick = function () {checkCard(14);}
	document.getElementById("card"+15).onclick = function () {checkCard(15);}
	

	function checkCard(id){
		var card =  document.getElementById("card" + id);
		var url = card.style.backgroundImage;
		if(url == 'url("Giochi/MarioMemory/retro.png")' || flag==2){
			if(flag == 0){
				stId = id;
				stClick = backGround[stId];
				flag = 1;
				divCard[stId].style.backgroundImage = 'url("Giochi/MarioMemory/' + backGround[stId] + '.png")';
				}
	
			else if (flag == 1){
				sdId = id;
				sdClick = backGround[sdId];
				flag = 2;
				divCard[sdId].style.backgroundImage = 'url("Giochi/MarioMemory/' + backGround[sdId] + '.png")';				
				}
				
			else if (flag==2){				
				if(stClick != sdClick){					
					divCard[stId].style.backgroundImage = 'url("Giochi/MarioMemory/retro.png")';
					divCard[sdId].style.backgroundImage = 'url("Giochi/MarioMemory/retro.png")';
				}
				flag=0;
			}
		}				
		checkGame();
	}
	function checkGame(){
		var retroCount = 0;
		var backG;
		var toCheck = "";
		for(var i = 0; i < 16; i++){
			backG = document.getElementById("card" + i);
			toCheck = backG.style.backgroundImage;
			
			if (toCheck == 'url("Giochi/MarioMemory/retro.png")'){
				retroCount++;				
			}				
		}
		if (retroCount == 0){
			clearInterval(toClear);
			alert ("Game over\nHai impiegato: " + record.innerHTML)
		}
	}
}

